package com.task.locatorptm.presentation;

import android.app.Application;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class LocatorApp extends Application {}
